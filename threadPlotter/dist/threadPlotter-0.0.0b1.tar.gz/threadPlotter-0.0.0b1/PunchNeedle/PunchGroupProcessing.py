'''
stores all utility functions related to punch point and setment calculation
'''

